'use strict';
const AWS = require("aws-sdk");
const sns = new AWS.SNS();
const comprehend = new AWS.Comprehend();
const ddb = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event, context, callback) => {

    let record = event.Records[0]
    console.log('Stream record: ', JSON.stringify(record, null, 2));
    
    if (record.eventName == 'INSERT') {
      let username = record.dynamodb.Keys.Username.S;
      let timestamp = record.dynamodb.Keys.Timestamp.S;
      let message = record.dynamodb.NewImage.Message?.S;
    
      let res = await comprehend.detectSentiment({"Text": message, "LanguageCode": "en"}).promise();
      
      await updateComment(username, timestamp, res['Sentiment']);
    }
    
    callback(null, `Successfully processed record.`);
};

function updateComment(username, timestamp, sentiment) {
  const params = {
      TableName: "CommentTable",
      Key: {
        "Username": username,
        "Timestamp": timestamp 
      },
      UpdateExpression: "SET #name = :value",
      ExpressionAttributeNames: {
          "#name": "Sentiment"
      },
      ExpressionAttributeValues: {
          ":value": sentiment
      }
  }
  console.log(params)
  return ddb.update(params).promise();
}
